from flask import Flask, render_template
import ssl

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/features')
def feature_route():
    return render_template('index2.html')

@app.route('/get_started')
def get_started():
    return render_template('index1.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', debug=True)
